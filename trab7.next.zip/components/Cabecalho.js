import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Nav, Navbar } from 'react-bootstrap';
const Cabecalho = () => {
    return (
        <>
            <Navbar style={{backgroundColor:'#1C1C1C'}} variant="primary" >
                <Container>
                    <Navbar.Brand href="/deputados/"  className='text-white'>Deputados</Navbar.Brand>
                    <Nav className="me-auto ">
                        <Nav.Link className='text-white' href="#pagina2">Página 1</Nav.Link>
                        <Nav.Link className='text-white' href="#array">Página 2</Nav.Link>
                        <Nav.Link className='text-white' href="#carros">Página 3</Nav.Link>
                    </Nav>
                </Container>
            </Navbar>
        </>
    )
}

export default Cabecalho